import React, { useState } from 'react';
import UploadFile from './UploadFile';
import axios from 'axios';
import { Box, Button, Container, Grid } from '@mui/material';
import Notification from '../snackbar/SnackbarNotification';
import { useSelector, useDispatch } from 'react-redux';
import { increment, reset } from '../../features/uploadFiles/uploadFileSlice';
import CircularProgress from '@mui/material/CircularProgress';
import {
  on,
  off
} from '../../features/generateBtnStatus/generateBtnStatusSlice';

const Screen_43 = () => {
  const [showNotification, setShowNotification] = useState(false);
  const [generateState, setGenerateState] = useState(true);
  const uploadFileCount = useSelector(state => state.uploadFile.count);
  const [showCircularProgress, setShowCircularProgress] = useState(false);

  const dispatch = useDispatch();
  const genBtnStat = useSelector(state => state.generateBtnStatus.status);
  const funcGenerateState = () => {
    setGenerateState(!generateState);
  };

  const funcSetUploadBtnDisabledState = () => {};

  const handleGetCFS = () => {
    setShowCircularProgress(true);
    if (uploadFileCount <= 3) {
      alert('Kindly upload files');
    }
    axios
      .get('http://localhost:8080/files/generate', {})
      .then(response => {
        console.log('Uploaded successfully', response);
        if (response.status === Number(200)) {
          setShowCircularProgress(false);
          setShowNotification(true);
          dispatch(reset());
          dispatch(off());

          console.log('uploadFileCount  =', uploadFileCount);
          console.log('GenStat', genBtnStat);
        }
        funcGenerateState();
      })
      .catch(error => {
        console.log('error in code');
        console.log('handleUploadClick called in error');
      });
  };

  return (
    <>
      <h3
        style={{
          textAlign: 'center',
          fontWeight: 'bold',
          color: '#79797b',
          marginTop: '10px'
        }}
      >
        Cashflow Generation Engine
      </h3>
      <Container
        style={{
          marginTop: 10,
          position: 'relative'
        }}
      >
        {/* ----------------------------------------- Main box 400 px height */}
        <Box
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-around'
          }}
        >
          <UploadFile
            title="Financial Data"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            api={'http://localhost:8080/files/upload/financial'}
            // handleCollectFiles={handleCollectFiles}
          />

          <UploadFile
            title="Client backup data (Optional)"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            api={'http://localhost:8080/files/upload/client'}
            // handleCollectFiles={handleCollectFiles}
          />

          <UploadFile
            title="Trial Balance"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            api={'http://localhost:8080/files/upload/trial'}
            // handleCollectFiles={handleCollectFiles}
          />

          {/* <UploadFile
            title="Notes to Financial Statement"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            // handleCollectFiles={handleCollectFiles}
          /> */}

          {/* <h4>Files Count : {uploadFileCount}</h4> */}

          <UploadFile
            title="Applicability"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            api={'http://localhost:8080/files/upload/applicability'}
            // handleCollectFiles={handleCollectFiles}
          />
        </Box>
        <Box
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-around'
          }}
        >
          <Button
            style={{ position: 'relative' }}
            sx={{
              mt: 2,
              width: '150px',
              bgcolor: '#999',
              color: '#ffffff',
              mt: 2,
              '&:hover': { bgcolor: '#111111', color: '#ffffff' }
            }}
            onClick={() => handleGetCFS()}
            disabled={uploadFileCount <= 3}
          >
            Generate CFS
          </Button>
          {showCircularProgress && (
            <CircularProgress style={{ position: 'absolute' }} />
          )}
          {showNotification && (
            <Notification msg="Generated Successfully" setShow={true} />
          )}
        </Box>
      </Container>
    </>
  );
};
export default Screen_43;
