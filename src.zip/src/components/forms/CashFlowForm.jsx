import React from 'react';
import UploadFile from './UploadFile';
import LinearProgress from '@mui/material/LinearProgress';
import axios from 'axios';
import { useState } from 'react';
import { Box, Button, Container, Grid } from '@mui/material';
import Notification from '../snackbar/SnackbarNotification';

const Screen_43 = () => {
  const [showNotification, setShowNotification] = useState(false);
  const [generateState, setGenerateState] = useState(true);

  const funcGenerateState = () => {
    setGenerateState(!generateState);
  };

  const funcSetUploadBtnDisabledState = () => {};

  const handleGetCFS = () => {
    axios
      .get('http://localhost:8080/files/generate', {})
      .then(response => {
        console.log('Uploaded successfully', response);
        if (response.status === Number(200)) {
          setShowNotification(true);
        }
        funcGenerateState();
      })
      .catch(error => {
        console.log('error in code');
        console.log('handleUploadClick called in error');
      });
  };

  return (
    <>
      <h3
        style={{
          textAlign: 'center',
          fontWeight: 'bold',
          color: '#79797b',
          marginTop: '10px'
        }}
      >
        Cashflow Generation Engine
      </h3>
      <Container
        style={{
          marginTop: 10
        }}
      >
        {/* ----------------------------------------- Main box 400 px height */}
        <Box
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-around'
          }}
        >
          <UploadFile
            title="Upload Balance Sheet"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            // handleCollectFiles={handleCollectFiles}
          />
          {/* 
          <UploadFile
            title="Upload Income Statement"
            uploadBtnDisabledState={true}
            setUploadBtnDisabledState
            funcGenerateState={funcGenerateState}
            funcSetUploadBtnDisabledState={funcSetUploadBtnDisabledState}
            handleCollectFiles={handleCollectFiles}
          /> */}

          {/* <UploadFile
          <Grid gap={5} width="300px">
              title="Income Statement"
              handleCollectFiles={handleCollectFiles}
            />

            <UploadFile
              title="Other Data"
              handleCollectFiles={handleCollectFiles}
            />
            <UploadFile
              title="Cashflow Template"
              handleCollectFiles={handleCollectFiles}
            />
            <UploadFile
              title="Applicability"
              handleCollectFiles={handleCollectFiles}
          </Grid>
            /> */}
        </Box>
        <Box
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-around'
          }}
        >
          <Button
            sx={{
              mt: 8,
              width: '150px',
              bgcolor: '#555555',
              color: '#ffffff',
              '&:hover': { bgcolor: '#111111', color: '#ffffff' }
            }}
            onClick={() => handleGetCFS()}
            disabled={generateState}
          >
            Generate CFS
          </Button>
          {showNotification && (
            <Notification msg="Generated Successfully" setShow={true} />
          )}
        </Box>
      </Container>
    </>
  );
};
export default Screen_43;
