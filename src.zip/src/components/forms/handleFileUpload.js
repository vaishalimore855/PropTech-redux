import React, { useState } from 'react';
const [file, setFile] = useState('');

function handleFileUpload(fileToUpload) {
  const file = fileToUpload[0];

  console.log('Files: ', fileToUpload);
  const formData = new FormData();
  formData.append('file', file);

  axios
    // .post(`${baseUrl}/upload`, formData, {
    .post('http://localhost:8080/files/upload', formData, {
      method: 'POST',
      body: file,
      headers: {
        'content-type': file.type,
        'content-length': `${file.size}`,
        'x-rapidapi-host': 'file-upload8.p.rapidapi.com',
        'x-rapidapi-key': 'your-rapidapi-key-here'
      }
    })
    .then(response => {
      // handle success response
      console.log('Uploaded successfully', response);
      console.log('handleUploadClick called successfu');
    })
    .catch(error => {
      // handle error response
      console.log('error in code');
      console.log('handleUploadClick called in error');
    });
}

export default handleFileUpload;

// axios
//   // .post(`${baseUrl}/upload`, formData, {
//   .get(`http://localhost:8080/files/upload/files/${855530f0-0632-465b-8208-fa004d1e682b}`,{
//     headers: {
//       'Content-Type': 'multipart/form-data',
//       'x-rapidapi-host': 'file-upload8.p.rapidapi.com',
//       'x-rapidapi-key': 'your-rapidapi-key-here'
//     }
//   })
//   .then(response => {
//     // handle success response
//     console.log('Uploaded successfully', response);
//     console.log('handleUploadClick called successfu');
//   })
//   .catch(error => {
//     // handle error response
//     console.log('error in code');
//     console.log('handleUploadClick called in error');
//   });
