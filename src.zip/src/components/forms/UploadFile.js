import React, { useState, useRef, useEffect } from 'react';
import Notification from '../snackbar/SnackbarNotification';
import axios from 'axios';
import { useSelector, useDispatch } from 'react-redux';
import { Box, Button, Container, Grid, Typography } from '@mui/material';
import AssignmentTurnedInRoundedIcon from '@mui/icons-material/AssignmentTurnedInRounded';
import OpenInBrowserIcon from '@mui/icons-material/OpenInBrowser';
import { increment } from '../../features/uploadFiles/uploadFileSlice';
import { green } from '@mui/material/colors';

const UploadFile = props => {
  let { title, funcGenerateState, funcSetFile, api } = props;
  const uploadFileCount = Number(useSelector(state => state.uploadFile.count));
  const dispatch = useDispatch();
  const [showNotification, setShowNotification] = useState(false);
  const fileInputRef1 = useRef();
  const [file, setFile] = useState(null);
  const formData = new FormData();
  const [uploadBtnDisabledState, setUploadBtnDisabledState] = useState(true);
  const [showBrowse, setShowBrowse] = useState(false);
  const [fileUploadStatus, setFileUploadStatus] = useState(false);
  const generateBtnStatus = useSelector(
    state => state.generateBtnStatus.status
  );

  // !generateState && setFile(null);

  const handleCollectFiles = e => {
    const file = fileInputRef1.current.files[0];
    setFile(file);
    // console.log(file);
    formData.append('file', file);
    // console.log(formData);
    setUploadBtnDisabledState(false);
  };

  const handleFileUpload = () => {
    console.log('API on upload ', api);
    // if (uploadBtnState === true) {
    //   alert('Select file first');
    // }
    const file = fileInputRef1.current.files[0];
    // console.log('2222222222222222222222', file);
    setFile(file);
    // console.log(file);
    formData.append('file', file);
    // ------------------------------------------------------- API request
    axios
      .post(`${props.api}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'content-Type': file.type,
          'x-rapidapi-host': 'file-upload8.p.rapidapi.com',
          'x-rapidapi-key': 'your-rapidapi-key-here'
        }
      })
      .then(response => {
        console.log('response: ', response);
        console.log('handleUploadClick called successfull');
        if (response.status === Number(200)) {
          setFileUploadStatus(true);
          setShowNotification(true);
          setUploadBtnDisabledState(true);
          funcGenerateState();
          // setFile(null);
          dispatch(increment());
        }
      })
      .catch(error => {
        // handle error response
        // console.log('error in code');
        // console.log('handleUploadClick called in error');
      });
  };

  return (
    <>
      <Grid
        style={{
          margin: '0px',
          marginBottom: '10px',
          border: '1px solid black',
          width: '30%',
          height: 230,
          borderRadius: '5px',
          position: 'relative'
        }}
      >
        <h5 style={{ textAlign: 'center', margin: '5px 0 18px' }}>{title}</h5>
        {fileUploadStatus && (
          <AssignmentTurnedInRoundedIcon
            sx={{ color: green[500] }}
            style={{
              position: 'absolute',
              right: '5px',
              top: '5px'
            }}
          />
        )}

        <Grid
          style={{ border: '1px dotted gray' }}
          sx={{
            height: 90,
            bgcolor: '#f0ecec',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center'
          }}
        >
          <Grid textAlign="center">
            <OpenInBrowserIcon
              style={{
                color: 'gray',
                fontSize: '40px',
                marginBottom: '2px'
              }}
            ></OpenInBrowserIcon>
            <Container
              sx={{
                display: 'flex',
                flexDirection: 'column',
                lineheight: '5px'
              }}
            >
              <Button
                variant=""
                component="label"
                sx={{
                  padding: '0px',

                  margin: '0px',
                  fontWeight: 'bold',
                  textTransform: 'none',
                  borderBottom: '2px solid black',
                  width: '30px'
                }}
              >
                Browse
                <input
                  disabled={showBrowse}
                  multiple
                  type="file"
                  hidden
                  name="fileInputRef1"
                  ref={fileInputRef1}
                  onChange={handleCollectFiles}
                  accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                />
              </Button>
              <hr />
            </Container>
          </Grid>
        </Grid>
        <Box
          textAlign="left"
          style={{ paddingLeft: '10px', backgroundColor: '#f6f6f6' }}
        >
          <Typography noWrap variant="subtitle2" component="h6">
            Filename :- {file && file.name}{' '}
          </Typography>

          {/* <Typography noWrap variant="subtitle2" component="h6">
            File Type :- {file && file.type}
          </Typography> */}

          <Typography noWrap variant="subtitle2" component="h6">
            File Size :- {file && file.size}
          </Typography>
        </Box>
        <Grid
          style={{ position: 'relative' }}
          sx={{ display: 'flex', justifyContent: 'center' }}
        >
          <Button
            variant="contained"
            sx={{
              width: '100px',
              bgcolor: '#555555',
              color: '#ffffff',
              mt: 2,
              '&:hover': { bgcolor: '#111111', color: '#ffffff' }
            }}
            onClick={() => handleFileUpload()}
            disabled={Boolean(uploadBtnDisabledState)}
          >
            Upload
          </Button>
          {showNotification && (
            <Notification msg="Uploaded Successfully" setShow={true} />
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default UploadFile;
