import logo from './logo.svg';
import react, { useState } from 'react';
import './App.css';
import CashFlowForm from './components/forms/CashFlowForm';
import FiveFilesUpload from './components/forms/FiveFilesUpload';
import UploadFileTest from './features/uploadFiles/UploadFileTest';
// import SingleFileUpload from './components/forms/ForSingleUpload';

function App() {
  return (
    <>
      {/* <UploadFileTest /> */}
      {/* <CashFlowForm /> */}
      <FiveFilesUpload />
      {/* <SingleFileUpload /> */}
    </>
  );
}

export default App;
