import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment } from './uploadFileSlice';

function UploadFileTest() {
  const dispatch = useDispatch();
  const count = useSelector(state => state.uploadFile.count);
  const handleUpload = () => {
    dispatch(increment());
  };
  return (
    <>
      <div>UploadFileTest- {count}</div>;
      <button onClick={handleUpload}>Add</button>
    </>
  );
}

export default UploadFileTest;
