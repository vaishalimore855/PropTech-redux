import { createSlice } from '@reduxjs/toolkit';
export const uploadFileSlice = createSlice({
  name: 'uploadFile',
  initialState: { count: 0 },
  reducers: {
    increment: state => {
      state.count += 1;
    },
    reset: state => {
      state.count = 0;
    }
  }
});

export const { increment, reset } = uploadFileSlice.actions;

export default uploadFileSlice.reducer;
