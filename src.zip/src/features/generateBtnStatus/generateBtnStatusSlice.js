import { createSlice } from '@reduxjs/toolkit';
export const generateBtnStatusSlice = createSlice({
  name: 'generateBtnStatus',
  initialState: { status: 'off' },
  reducers: {
    on: state => {
      state.status = 'on';
    },
    off: state => {
      state.status = 'off';
    }
  }
});

export const { on, off } = generateBtnStatusSlice.actions;

export default generateBtnStatusSlice.reducer;
