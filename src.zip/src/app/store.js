import { configureStore } from '@reduxjs/toolkit';
import uploadFileReducer from '../features/uploadFiles/uploadFileSlice';
import generateBtnStatusReducer from '../features/generateBtnStatus/generateBtnStatusSlice';

export default configureStore({
  reducer: {
    uploadFile: uploadFileReducer,
    generateBtnStatus: generateBtnStatusReducer
  }
});
